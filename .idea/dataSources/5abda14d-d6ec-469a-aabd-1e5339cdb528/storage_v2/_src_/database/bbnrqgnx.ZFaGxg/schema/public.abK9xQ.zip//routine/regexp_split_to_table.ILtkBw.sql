CREATE FUNCTION regexp_split_to_table(citext, citext)
  RETURNS SETOF text
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT pg_catalog.regexp_split_to_table( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$$;

