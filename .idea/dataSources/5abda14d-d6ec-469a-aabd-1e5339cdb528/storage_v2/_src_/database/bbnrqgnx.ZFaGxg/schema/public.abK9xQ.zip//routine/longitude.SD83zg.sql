CREATE FUNCTION longitude(earth)
  RETURNS double precision
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT degrees(atan2(cube_ll_coord($1, 2), cube_ll_coord($1, 1)))
$$;

