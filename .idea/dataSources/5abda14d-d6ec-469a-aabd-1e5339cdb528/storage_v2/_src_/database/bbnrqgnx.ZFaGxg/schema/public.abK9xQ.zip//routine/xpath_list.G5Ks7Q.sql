CREATE FUNCTION xpath_list(text, text)
  RETURNS text
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT xpath_list($1,$2,',')
$$;

