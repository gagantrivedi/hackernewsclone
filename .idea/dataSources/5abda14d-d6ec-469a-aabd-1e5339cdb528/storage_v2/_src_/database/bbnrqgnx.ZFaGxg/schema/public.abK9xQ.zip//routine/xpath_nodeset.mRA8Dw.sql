CREATE FUNCTION xpath_nodeset(text, text)
  RETURNS text
IMMUTABLE
STRICT
LANGUAGE SQL
AS $$
SELECT xpath_nodeset($1,$2,'','')
$$;

